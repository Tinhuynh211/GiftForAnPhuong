import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchAllQuestions } from "../redux/actions/questionsAction";
import { Card, Form, Spinner } from "react-bootstrap";
import CardQuestion from "../components/CardQuestion";

function Quiz() {
  const { questions, isLoading } = useSelector((state) => state.questions);
  const [score, setScore] = useState(0)

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchAllQuestions());
  }, []);

  return (
    <div
      style={{
        padding: 40,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 20,
      }}
    >
      <p style={{fontSize: '20px', fontWeight: 700}}>You got {score} scores</p>
      {isLoading ? (
        <div style={{ display: "flex", gap: 20 }}>
          <Spinner animation="grow" size="sm" />
          <Spinner animation="grow" size="sm" />
          <Spinner animation="grow" size="sm" />
        </div>
      ) : (
        questions.map((question, index) => (
          <CardQuestion
          setScore={setScore}
            question={question}
            index={index}
            key={question.id}
          ></CardQuestion>
        ))
      )}
    </div>
  );
}

export default Quiz;
